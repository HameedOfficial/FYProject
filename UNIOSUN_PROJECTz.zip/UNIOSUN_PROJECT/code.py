import tkinter as tk
from tkinter import messagebox, simpledialog
import cv2
from PIL import Image, ImageTk
import os

# --- Global Variables ---
cap = None  # Webcam capture object
photo_label = None # Label to display the camera feed
current_frame = None # To store the last captured frame for saving
is_verifying = False # Flag to indicate if we are in verification mode

# --- Functions for Camera and Image Handling ---

def open_camera():
    """
    Initializes the camera and starts displaying the live feed.
    """
    global cap, photo_label, is_verifying
    is_verifying = False # Ensure not in verification flow when opening camera directly

    if cap and cap.isOpened(): # If camera is already open, release it first
        release_camera()

    cap = cv2.VideoCapture(0) # Open the default camera

    if not cap.isOpened():
        messagebox.showerror("Camera Error", "Could not open camera. Please check if it's connected and not in use.")
        return

    # Create or update a Label to display the video frames
    if photo_label is None:
        photo_label = tk.Label(root)
        photo_label.pack(pady=10)
    else:
        photo_label.pack(pady=10) # Ensure it's packed if it was hidden

    # Start updating the feed
    update_feed()
    status_label.config(text="Camera active. Click 'Snap' to capture.")
    snap_button.config(state=tk.NORMAL) # Enable snap button once camera is open
    verify_button.config(state=tk.DISABLED) # Disable verify button when camera is on
    open_button.config(state=tk.DISABLED) # Disable open camera button when on

def update_feed():
    """
    Reads a frame from the camera and updates the Tkinter label with the image.
    This function calls itself recursively to create a live feed.
    """
    global current_frame
    if cap and cap.isOpened():
        ret, frame = cap.read()
        if ret:
            current_frame = frame # Store the current frame for later saving

            # Convert the image from OpenCV BGR format to RGB format for PIL
            cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
            img = Image.fromarray(cv2image)

            # Convert to ImageTk format for Tkinter
            imgtk = ImageTk.PhotoImage(image=img)

            # Update the label with the new image
            photo_label.imgtk = imgtk # Keep a reference!
            photo_label.config(image=imgtk)

            # Call this function again after 10 milliseconds to create a live feed
            photo_label.after(10, update_feed)
        else:
            messagebox.showwarning("Camera Warning", "Could not read frame from camera.")
            release_camera()
    else:
        # If camera is not open, ensure snap button is disabled
        snap_button.config(state=tk.DISABLED)
        # Re-enable verify and open buttons if camera is not active and not in verification flow
        if not is_verifying:
            verify_button.config(state=tk.NORMAL)
            open_button.config(state=tk.NORMAL)


def snap_picture():
    """
    Captures the current frame, prompts for a name, and saves the image.
    """
    if current_frame is None:
        messagebox.showwarning("No Image", "No frame available to snap. Please ensure camera is active.")
        return

    person_name = simpledialog.askstring("Enter Name", "Please enter the name of the person:")

    if person_name:
        # Sanitize the name for filename (replace spaces with underscores, remove special chars)
        safe_name = "".join(c for c in person_name if c.isalnum() or c.isspace()).strip()
        safe_name = safe_name.replace(" ", "_")

        if not safe_name:
            messagebox.showwarning("Invalid Name", "Name cannot be empty or contain only special characters. Picture not saved.")
            return

        filename = f"{safe_name}.jpg"
        save_path = os.path.join("captured_faces", filename) # Save in a subfolder

        # Create the directory if it doesn't exist
        os.makedirs("captured_faces", exist_ok=True)

        try:
            cv2.imwrite(save_path, current_frame)
            messagebox.showinfo("Success", f"Picture saved as '{save_path}'!")
            status_label.config(text=f"Picture saved: {filename}")
        except Exception as e:
            messagebox.showerror("Save Error", f"Failed to save picture: {e}")
            status_label.config(text="Picture save failed.")
    else:
        messagebox.showinfo("Cancelled", "Picture not saved as no name was entered.")
        status_label.config(text="Snap cancelled.")

def release_camera():
    """
    Releases the camera resource and cleans up.
    """
    global cap, photo_label, is_verifying
    if cap:
        cap.release()
        cap = None
    if photo_label:
        photo_label.config(image='') # Clear the image from the label
        photo_label.pack_forget() # Hide the label when camera is off
    cv2.destroyAllWindows() # Close any OpenCV windows (like imshow)
    status_label.config(text="Camera off. Click 'Open Camera' or 'Verify Face'.")
    snap_button.config(state=tk.DISABLED) # Disable snap button when camera is off
    verify_button.config(state=tk.NORMAL) # Enable verify button
    open_button.config(state=tk.NORMAL) # Enable open camera button
    is_verifying = False

# --- Verification Logic ---

def verify_face_by_name():
    """
    Prompts for a name and checks if a picture with that name exists.
    If it exists, opens the camera. If not, prompts again.
    """
    global is_verifying
    is_verifying = True # Set flag to indicate verification mode
    release_camera() # Ensure camera is off before starting verification flow

    while True:
        person_name = simpledialog.askstring("Verify Name", "Enter the name of the person to verify:", parent=root)

        if person_name is None: # User clicked cancel
            messagebox.showinfo("Verification Cancelled", "Verification process cancelled.")
            status_label.config(text="Verification cancelled.")
            is_verifying = False # Reset flag
            break

        # Sanitize the name for filename
        safe_name = "".join(c for c in person_name if c.isalnum() or c.isspace()).strip()
        safe_name = safe_name.replace(" ", "_")

        if not safe_name:
            messagebox.showwarning("Invalid Name", "Name cannot be empty or contain only special characters. Please try again.")
            continue # Ask for name again

        filename = f"{safe_name}.jpg"
        image_path = os.path.join("captured_faces", filename)

        if os.path.exists(image_path):
            messagebox.showinfo("Record Found", f"Record for '{person_name}' found! Opening camera for live verification.")
            status_label.config(text=f"Record found for '{person_name}'. Camera starting...")
            open_camera() # Open camera for actual verification (or just display)
            is_verifying = False # Reset flag once camera is open
            break # Exit loop
        else:
            response = messagebox.askyesno(
                "No Record Found",
                f"No record found for '{person_name}'. Do you want to try another name?",
                icon='warning'
            )
            if not response: # User chose not to try another name
                messagebox.showinfo("Verification Failed", "Verification failed. No matching record.")
                status_label.config(text="Verification failed. No record found.")
                is_verifying = False # Reset flag
                break

# --- Tkinter GUI Setup ---

root = tk.Tk()
root.title("Live Camera, Snap & Verify")
root.geometry("600x550") # Adjust size to accommodate video feed

# Bind the close window event to release the camera
root.protocol("WM_DELETE_WINDOW", lambda: [release_camera(), root.destroy()])

# Create buttons in a frame for better layout
button_frame = tk.Frame(root)
button_frame.pack(pady=10)

open_button = tk.Button(button_frame, text="Open Camera", command=open_camera,
                        width=15, height=2, bg="#4CAF50", fg="white", font=('Arial', 10, 'bold'))
open_button.pack(side=tk.LEFT, padx=5)

snap_button = tk.Button(button_frame, text="Snap Picture", command=snap_picture,
                        width=15, height=2, bg="#2196F3", fg="white", font=('Arial', 10, 'bold'), state=tk.DISABLED) # Start disabled
snap_button.pack(side=tk.LEFT, padx=5)

verify_button = tk.Button(button_frame, text="Verify Face", command=verify_face_by_name,
                          width=15, height=2, bg="#FFC107", fg="black", font=('Arial', 10, 'bold'))
verify_button.pack(side=tk.LEFT, padx=5)

close_button = tk.Button(button_frame, text="Close Camera", command=release_camera,
                         width=15, height=2, bg="#f44336", fg="white", font=('Arial', 10, 'bold'))
close_button.pack(side=tk.LEFT, padx=5)


# Status label at the bottom
status_label = tk.Label(root, text="Click 'Open Camera' or 'Verify Face' to begin.", bd=1, relief=tk.SUNKEN, anchor=tk.W)
status_label.pack(side=tk.BOTTOM, fill=tk.X, ipadx=5, ipady=5)

# Start the Tkinter event loop
root.mainloop()