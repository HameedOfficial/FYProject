import tkinter as tk
from tkinter import messagebox, simpledialog
import cv2
from PIL import Image, ImageTk
import os

# --- Global Variables ---
cap = None
photo_label = None
current_frame = None
face_and_features_detected = False

# --- Debugging: Print current working directory and check file existence ---
print(f"Current working directory: {os.getcwd()}")

# List of cascade files to load
cascade_files = {
    "face": 'haarcascade_frontalface_default.xml',
    "eye": 'haarcascade_eye.xml',
    "nose": 'haarcascade_nose.xml'
}

loaded_cascades = {}
all_cascades_loaded = True

for name, filename in cascade_files.items():
    full_path = os.path.join(os.getcwd(), filename)
    print(f"Attempting to load {name} cascade from: {full_path}")

    if not os.path.exists(full_path):
        print(f"ERROR: File does NOT exist at this path: {full_path}")
        all_cascades_loaded = False
        break # No point continuing if one is missing

    cascade = cv2.CascadeClassifier(full_path)
    if cascade.empty():
        print(f"ERROR: {filename} loaded empty. File might be corrupt or malformed.")
        all_cascades_loaded = False
        break
    loaded_cascades[name] = cascade
    print(f"{filename} loaded successfully.")

# Assign loaded cascades to main variables if all loaded
if all_cascades_loaded:
    face_cascade = loaded_cascades["face"]
    eye_cascade = loaded_cascades["eye"]
    nose_cascade = loaded_cascades["nose"]
else:
    messagebox.showerror("Error", "Could not load one or more Haar Cascade XML files. Please check file names, location, and ensure they are not corrupted.")
    exit() # Exit the application if cascades aren't loaded

# --- Rest of your code follows below (no changes needed to functions) ---
# ... (your open_camera, update_feed, capture_picture, release_camera functions) ...