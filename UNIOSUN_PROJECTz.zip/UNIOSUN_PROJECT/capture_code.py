import tkinter as tk
from tkinter import messagebox, simpledialog
import cv2
from PIL import Image, ImageTk
import os

# --- Global Variables ---
cap = None
photo_label = None
current_frame = None
face_detected_in_frame = False

# NEW Global Variables for Multi-Capture
current_person_folder = None
capture_count = 0
MAX_CAPTURES = 5 # Total number of pictures to take for each person

# Load ONLY the Haar Cascade classifier for face detection
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

if face_cascade.empty():
    messagebox.showerror(
        "Error Loading Cascade",
        "Could not load 'haarcascade_frontalface_default.xml'.\n\n"
        "Please ensure it is in the same directory as this script and is not corrupted."
    )
    exit()

# --- Functions for Camera and Image Handling ---

def open_camera():
    global cap, photo_label, current_person_folder, capture_count

    if cap and cap.isOpened():
        release_camera()

    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        messagebox.showerror("Camera Error", "Could not open camera. Please check if it's connected and not in use, or try changing '0' to '1' or '2'.")
        return

    if photo_label is None:
        photo_label = tk.Label(root)
        photo_label.pack(pady=10)
    else:
        photo_label.pack(pady=10)

    # Reset multi-capture state when camera is opened
    current_person_folder = None
    capture_count = 0
    
    update_feed()
    status_label.config(text="Camera active. Looking for a human face...")
    capture_button.config(state=tk.DISABLED)
    open_button.config(state=tk.DISABLED)

def update_feed():
    global current_frame, face_detected_in_frame

    if cap and cap.isOpened():
        ret, frame = cap.read()
        if ret:
            current_frame = frame.copy()
            display_frame = frame.copy()

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

            faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80))

            if len(faces) > 0:
                face_detected_in_frame = True
                
                if current_person_folder is None:
                    status_label.config(text="Human face detected! Ready to capture. ✅")
                else:
                    status_label.config(text=f"Capturing for {os.path.basename(current_person_folder)}. Picture {capture_count + 1} of {MAX_CAPTURES}. Face detected! ✅")
                    
                capture_button.config(state=tk.NORMAL)
                
                for (x, y, w, h) in faces:
                    cv2.rectangle(display_frame, (x, y), (x+w, y+h), (255, 0, 0), 2)

            else:
                face_detected_in_frame = False
                if current_person_folder is None:
                    status_label.config(text="No human detected. Please position your face in front of the camera. 🚫")
                else:
                    status_label.config(text=f"Capturing for {os.path.basename(current_person_folder)}. Picture {capture_count + 1} of {MAX_CAPTURES}. No face detected. 🚫")
                capture_button.config(state=tk.DISABLED)

            cv2image = cv2.cvtColor(display_frame, cv2.COLOR_BGR2RGBA)
            img = Image.fromarray(cv2image)
            imgtk = ImageTk.PhotoImage(image=img)

            photo_label.imgtk = imgtk
            photo_label.config(image=imgtk)

            photo_label.after(10, update_feed)
        else:
            messagebox.showwarning("Camera Warning", "Could not read frame from camera. It might be disconnected or used by another application.")
            release_camera()
    else:
        capture_button.config(state=tk.DISABLED)
        open_button.config(state=tk.NORMAL)


def capture_picture():
    global face_detected_in_frame, current_person_folder, capture_count

    if not face_detected_in_frame:
        messagebox.showwarning("No Face", "No human face detected. Please ensure a face is visible before capturing.")
        return

    if current_frame is None:
        messagebox.showwarning("No Image", "No frame available to capture. Please ensure camera is active.")
        return
    
    frame_to_save = current_frame.copy()

    if current_person_folder is None:
        person_name = simpledialog.askstring("Enter Name", "Please enter the name of the person:", parent=root)

        if not person_name:
            messagebox.showinfo("Cancelled", "Picture sequence cancelled as no name was entered.")
            status_label.config(text="Capture cancelled.")
            return

        safe_name = "".join(c for c in person_name if c.isalnum() or c.isspace()).strip()
        safe_name = safe_name.replace(" ", "_")

        if not safe_name:
            messagebox.showwarning("Invalid Name", "Name cannot be empty or contain only special characters. Picture sequence not started.")
            return
        
        base_capture_dir = "captured_faces"
        os.makedirs(base_capture_dir, exist_ok=True)

        current_person_folder = os.path.join(base_capture_dir, safe_name)
        os.makedirs(current_person_folder, exist_ok=True)
        
        capture_count = 0

    if current_person_folder:
        capture_count += 1
        filename = f"{capture_count:03d}.jpg"
        save_path = os.path.join(current_person_folder, filename)

        try:
            cv2.imwrite(save_path, frame_to_save)
            messagebox.showinfo("Success", f"Picture {capture_count} saved as '{save_path}'!")
            status_label.config(text=f"Picture {capture_count} saved for {os.path.basename(current_person_folder)}.")

            if capture_count < MAX_CAPTURES:
                status_label.config(text=f"Picture {capture_count} saved. Please prepare for picture {capture_count + 1} of {MAX_CAPTURES}.")
                capture_button.config(state=tk.DISABLED)
            else:
                messagebox.showinfo("Complete", f"All {MAX_CAPTURES} pictures saved for {os.path.basename(current_person_folder)}.")
                status_label.config(text=f"All pictures saved for {os.path.basename(current_person_folder)}. Click 'Open Camera' to start a new person.")
                current_person_folder = None
                capture_count = 0
                capture_button.config(state=tk.DISABLED) # Disable until a new person starts or camera reopened
                open_button.config(state=tk.NORMAL) # Re-enable open camera button after sequence complete

        except Exception as e:
            messagebox.showerror("Save Error", f"Failed to save picture {capture_count}: {e}")
            status_label.config(text=f"Picture {capture_count} save failed.")
            current_person_folder = None
            capture_count = 0
            capture_button.config(state=tk.DISABLED)
    else:
        messagebox.showwarning("Error", "No person folder set. This shouldn't happen.")
        status_label.config(text="An unexpected error occurred.")


def release_camera():
    global cap, photo_label, face_detected_in_frame, current_person_folder, capture_count
    if cap:
        cap.release()
        cap = None
    if photo_label:
        photo_label.config(image='')
        photo_label.pack_forget()
    cv2.destroyAllWindows()
    status_label.config(text="Camera off. Click 'Open Camera' to start capturing.")
    capture_button.config(state=tk.DISABLED)
    open_button.config(state=tk.NORMAL)
    face_detected_in_frame = False
    current_person_folder = None
    capture_count = 0

# --- Tkinter GUI Setup ---

root = tk.Tk()
root.title("Face Capture App")
root.geometry("600x650") # Increased height to accommodate instructions

root.protocol("WM_DELETE_WINDOW", lambda: [release_camera(), root.destroy()])

# --- Instructions Section ---
instructions_text = (
    "INSTRUCTION\n"
    "1. Click 'Open Camera' to start the live feed.\n"
    "2. Position your face in front of the camera until 'Human face detected!' appears.\n"
    "3. Click 'Capture'. If it's the first picture for a new person, you'll be prompted for a name.\n"
    "4. The system will guide you to take 5 pictures in total for each person.\n"
    "5. Click 'Close Camera' when done."
)
instructions_label = tk.Label(root, text=instructions_text, justify=tk.LEFT, wraplength=580, 
                              font=('Arial', 9), bg="#a72828", fg='#333333', padx=10, pady=10)
instructions_label.pack(pady=5, padx=10, fill=tk.X)

# A small separator for visual clarity
separator = tk.Frame(root, height=2, bd=1, relief=tk.SUNKEN)
separator.pack(fill=tk.X, padx=5, pady=5)

# --- End Instructions Section ---

button_frame = tk.Frame(root)
button_frame.pack(pady=10)

open_button = tk.Button(button_frame, text="Open Camera", command=open_camera,
                        width=15, height=2, bg="#4CAF50", fg="white", font=('Arial', 10, 'bold'))
open_button.pack(side=tk.LEFT, padx=10)

capture_button = tk.Button(button_frame, text="Capture", command=capture_picture,
                        width=15, height=2, bg="#2196F3", fg="white", font=('Arial', 10, 'bold'), state=tk.DISABLED)
capture_button.pack(side=tk.LEFT, padx=10)

close_button = tk.Button(button_frame, text="Close Camera", command=release_camera,
                         width=15, height=2, bg="#f44336", fg="white", font=('Arial', 10, 'bold'))
close_button.pack(side=tk.LEFT, padx=10)

status_label = tk.Label(root, text="Click 'Open Camera' to begin.", bd=1, relief=tk.SUNKEN, anchor=tk.W)
status_label.pack(side=tk.BOTTOM, fill=tk.X, ipadx=5, ipady=5)

root.mainloop()