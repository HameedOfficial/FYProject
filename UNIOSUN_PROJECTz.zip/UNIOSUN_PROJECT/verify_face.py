import tkinter as tk
from tkinter import messagebox
import cv2
from PIL import Image, ImageTk
import os
import numpy as np
import face_recognition
import time # Import the time module

# --- Global Variables ---
cap = None # Webcam capture object (single instance for both modes)
photo_label = None # Label to display the camera feed
known_face_encodings = [] # Stores encodings of known faces
known_face_names = [] # Stores names corresponding to known faces
loaded_known_faces = False # Flag to ensure faces are loaded only once

# Main Verification Page state
face_detection_active = False # Controls the update_feed loop for main page
recognized_person_name = None # Stores the name of the last recognized person (for login)

# Exam Page state
exam_warning_count = 0
MAX_WARNINGS = 3
EXAM_ACTIVE = False # Controls continuous monitoring during exam
CURRENT_EXAM_PERSON_ENCODING = None # Encoding of the person currently taking the exam
CURRENT_EXAM_PERSON_NAME = None # Name of the person currently taking the exam
exam_status_label = None # To show exam specific messages
no_face_frames_count = 0 # Counter for consecutive frames with no face detected
NO_FACE_DETECTION_BUFFER = 5 # Number of consecutive frames without a face before a warning is triggered

# Face recognition tolerance - Adjusted for robustness
# Lower value means stricter match, higher value means more forgiving
FACE_RECOGNITION_TOLERANCE = 0.70 # Increased from 0.65 to 0.70

# New: Timing variables for exam mode face recognition
last_face_check_time = 0 # Stores the timestamp of the last face recognition check
# Increased from 1000ms to 3000ms for a longer delay
CHECK_INTERVAL_MS = 3000 # milliseconds (3 seconds) between face recognition checks

# Dummy CBT Questions
dummy_questions = [
    {"question": "What is 2 + 2?", "options": ["3", "4", "5", "6"], "answer": "4"},
    {"question": "What is the capital of France?", "options": ["Berlin", "Madrid", "Paris", "Rome"], "answer": "Paris"},
    {"question": "Which planet is known as the Red Planet?", "options": ["Earth", "Mars", "Jupiter", "Venus"], "answer": "Mars"},
    {"question": "What is the largest ocean on Earth?", "options": ["Atlantic", "Indian", "Arctic", "Pacific"], "answer": "Pacific"},
]
current_question_index = 0
question_label = None
options_buttons = []

# Tkinter UI Frames - Defined globally for easy access
instructions_frame = None
button_frame = None
cbt_frame = None # New frame for CBT questions
main_camera_frame = None # Frame to hold the camera feed and status for both modes

# Load Haar Cascade classifier
face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

if face_cascade.empty():
    messagebox.showerror(
        "Error Loading Cascade",
        "Could not load 'haarcascade_frontalface_default.xml'.\n\n"
        "Please ensure it is in the same directory as this script and is not corrupted."
    )

# --- Functions for Face Recognition Data Loading ---

def load_known_faces(data_dir="captured_faces"):
    """
    Loads known face encodings and names from the 'captured_faces' directory.
    """
    global known_face_encodings, known_face_names, loaded_known_faces

    known_face_encodings = []
    known_face_names = []
    loaded_known_faces = False

    status_label.config(text="Loading known faces... Please wait.")
    root.update_idletasks()

    if not os.path.exists(data_dir):
        messagebox.showwarning("Data Error", f"The directory '{data_dir}' does not exist. Please capture faces first.")
        status_label.config(text="No known faces directory found. Capture faces first using the 'Capture' app.")
        return

    for person_name_folder in os.listdir(data_dir):
        person_folder_path = os.path.join(data_dir, person_name_folder)
        if os.path.isdir(person_folder_path):
            person_name = person_name_folder.replace("_", " ")

            for image_file in os.listdir(person_folder_path):
                if image_file.lower().endswith(('.png', '.jpg', '.jpeg')):
                    image_path = os.path.join(person_folder_path, image_file)
                    try:
                        image = face_recognition.load_image_file(image_path)
                        face_locations = face_recognition.face_locations(image)
                        face_encodings = face_recognition.face_encodings(image, face_locations)

                        if len(face_encodings) > 0:
                            known_face_encodings.append(face_encodings[0])
                            known_face_names.append(person_name)
                    except Exception as e:
                        print(f"Error loading {image_path}: {e}")
                        messagebox.showwarning("Image Load Error", f"Could not load image {image_file} for {person_name}: {e}")

    loaded_known_faces = True
    if len(known_face_encodings) > 0:
        status_label.config(text=f"Loaded {len(known_face_encodings)} known faces. Ready for verification.")
        print(f"Successfully loaded {len(known_face_encodings)} known faces from {len(set(known_face_names))} unique individuals.")
    else:
        status_label.config(text="No known faces found. Please capture faces first using the 'Capture' app.")
        print("No known faces found.")

#----------------------------------------------------------------------------------------------------------------------

# --- Main Camera and UI Management Functions ---

def open_camera():
    """
    Initializes the camera and starts displaying the live feed.
    """
    global cap, photo_label, face_detection_active, recognized_person_name, main_camera_frame, no_face_frames_count, last_face_check_time

    if cap and cap.isOpened():
        release_camera()

    cap = cv2.VideoCapture(0) # 0 for default webcam, try 1 or 2 if not working

    if not cap.isOpened():
        messagebox.showerror("Camera Error", "Could not open camera. Please check if it's connected and not in use, or try changing '0' to '1' or '2'.")
        return

    # Always pack main_camera_frame here as it's the container for the camera feed
    main_camera_frame.pack(pady=10, padx=10, fill="both", expand=True)

    # Re-create photo_label every time the camera is opened to ensure it's always valid
    # and properly associated with the current Tkinter context.
    # This also implicitly handles the 'NoneType' error by ensuring it's not None.
    photo_label = tk.Label(main_camera_frame)
    photo_label.pack(side=tk.TOP, pady=5)
    
    load_known_faces() 
    recognized_person_name = None
    no_face_frames_count = 0 # Reset buffer on camera open
    last_face_check_time = time.time() * 1000 # Initialize with current time in milliseconds

    face_detection_active = True # Enable initial verification mode
    EXAM_ACTIVE = False # Ensure exam mode is off
    
    update_feed() # Start the camera feed update loop
    status_label.config(text="Camera active. Looking for faces to verify...")
    open_button.config(state=tk.DISABLED)

def update_feed():
    """
    Reads a frame from the camera and performs either initial verification
    or continuous exam monitoring based on global flags.
    """
    global cap, photo_label, face_detection_active, recognized_person_name, exam_warning_count, no_face_frames_count
    global EXAM_ACTIVE, CURRENT_EXAM_PERSON_ENCODING, CURRENT_EXAM_PERSON_NAME, exam_status_label, last_face_check_time

    if cap and cap.isOpened():
        ret, frame = cap.read()
        if ret:
            # Flip frame horizontally to mirror the view (more intuitive)
            frame = cv2.flip(frame, 1)

            small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
            rgb_small_frame = cv2.cvtColor(small_frame, cv2.COLOR_BGR2RGB)

            face_locations = []
            face_encodings = []

            # Text to display on the video feed
            feed_text = ""
            feed_text_color = (255, 255, 255) # White

            # --- Logic branches based on whether we're in verification or exam mode ---
            if EXAM_ACTIVE:
                current_time = time.time() * 1000 # Current time in milliseconds
                
                # Only perform face recognition every CHECK_INTERVAL_MS
                if current_time - last_face_check_time >= CHECK_INTERVAL_MS:
                    face_locations = face_recognition.face_locations(rgb_small_frame)
                    face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)
                    last_face_check_time = current_time # Update the last check time

                    # --- Continuous Exam Monitoring Logic (within timed check) ---
                    face_verified_as_logged_in_person = False
                    
                    if face_encodings: # Check if any faces are detected in this timed recognition
                        no_face_frames_count = 0 # Reset buffer if a face is detected
                        for face_encoding in face_encodings:
                            # Compare detected face with the enrolled person's encoding
                            matches = face_recognition.compare_faces(
                                [CURRENT_EXAM_PERSON_ENCODING], face_encoding, tolerance=FACE_RECOGNITION_TOLERANCE
                            )
                            print(f"Exam Monitoring: Face detected. Matches original user: {matches[0]} (Tolerance: {FACE_RECOGNITION_TOLERANCE})") # Debug print
                            if matches[0]:
                                face_verified_as_logged_in_person = True
                                break # Found the logged-in person, no need to check other faces
                        
                        if face_verified_as_logged_in_person:
                            if exam_warning_count > 0:
                                exam_warning_count = 0 # Reset warnings if original person is back
                                exam_status_label.config(text=f"Welcome back, {CURRENT_EXAM_PERSON_NAME}! Monitoring face...", fg="black")
                            else:
                                exam_status_label.config(text=f"Monitoring: {CURRENT_EXAM_PERSON_NAME} ✅", fg="black")
                            feed_text = f"User: {CURRENT_EXAM_PERSON_NAME} (OK)"
                            feed_text_color = (0, 255, 0) # Green
                        else:
                            # Face detected but not the original person
                            exam_warning_count += 1
                            feed_text = "WARNING: Unauthorized face!"
                            feed_text_color = (0, 0, 255) # Red
                            if exam_warning_count <= MAX_WARNINGS:
                                exam_status_label.config(
                                    text=f"⚠️ WARNING {exam_warning_count}/{MAX_WARNINGS}: Unauthorized face detected! Please ensure {CURRENT_EXAM_PERSON_NAME} is visible.",
                                    fg="red"
                                )
                            else:
                                logout_from_exam(f"Too many warnings ({MAX_WARNINGS}). Auto-logging out.")
                                return # Stop further processing if logged out
                    else:
                        # No face detected at all in this timed recognition
                        no_face_frames_count += 1
                        print(f"Exam Monitoring: No face detected. Buffer: {no_face_frames_count}/{NO_FACE_DETECTION_BUFFER}") # Debug print
                        if no_face_frames_count >= NO_FACE_DETECTION_BUFFER:
                            exam_warning_count += 1
                            feed_text = "WARNING: No face detected!"
                            feed_text_color = (0, 0, 255) # Red
                            if exam_warning_count <= MAX_WARNINGS:
                                exam_status_label.config(
                                    text=f"⚠️ WARNING {exam_warning_count}/{MAX_WARNINGS}: No face detected! Please ensure {CURRENT_EXAM_PERSON_NAME} is visible.",
                                    fg="red"
                                )
                            else:
                                logout_from_exam(f"Too many warnings ({MAX_WARNINGS}). Auto-logging out.")
                                return # Stop further processing if logged out
                        else:
                            # Still within buffer, just indicate no face
                            feed_text = "No face detected (buffering...)"
                            feed_text_color = (255, 165, 0) # Orange
                            exam_status_label.config(text=f"No face detected. Buffering warnings...", fg="orange")
                    
                    print(f"Exam Warning Count: {exam_warning_count}") # Debug print
                else:
                    # If not time for a full check, just display current status or last known status
                    # Calculate remaining time for next check
                    remaining_time_sec = int((CHECK_INTERVAL_MS - (current_time - last_face_check_time)) / 1000) + 1
                    if exam_status_label.cget("text").startswith("Monitoring"):
                        feed_text = f"Monitoring: {CURRENT_EXAM_PERSON_NAME} (Next check in {remaining_time_sec}s)"
                        feed_text_color = (0, 255, 0)
                    elif exam_status_label.cget("text").startswith("⚠️ WARNING"):
                        feed_text = f"WARNING (Next check in {remaining_time_sec}s)"
                        feed_text_color = (0, 0, 255)
                    else:
                        feed_text = f"Checking soon... ({remaining_time_sec}s)"
                        feed_text_color = (255, 255, 0) # Yellow

                # Draw blue box for any detected face (this still happens every frame to show presence)
                current_frame_face_locations = face_recognition.face_locations(rgb_small_frame) # Re-detect just for drawing boxes
                for (top, right, bottom, left) in current_frame_face_locations:
                    top *= 4
                    right *= 4
                    bottom *= 4
                    left *= 4
                    cv2.rectangle(frame, (left, top), (right, bottom), (255, 0, 0), 2) # Blue box for any detected face

            elif face_detection_active: # This block handles initial login verification (no delay here, needs to be fast)
                face_locations = face_recognition.face_locations(rgb_small_frame)
                face_encodings = face_recognition.face_encodings(rgb_small_frame, face_locations)

                current_frame_face_names = []
                recognized_this_frame = False
                best_match_name_for_prompt = None
                best_match_encoding_for_prompt = None 

                for face_encoding in face_encodings:
                    name = "Unknown"
                    if len(known_face_encodings) > 0:
                        matches = face_recognition.compare_faces(known_face_encodings, face_encoding, tolerance=FACE_RECOGNITION_TOLERANCE)
                        face_distances = face_recognition.face_distance(known_face_encodings, face_encoding)
                        
                        if len(face_distances) > 0:
                            best_match_index = np.argmin(face_distances)
                            if matches[best_match_index]:
                                name = known_face_names[best_match_index]
                                recognized_this_frame = True
                                best_match_name_for_prompt = name
                                best_match_encoding_for_prompt = known_face_encodings[best_match_index]
                    current_frame_face_names.append(name)
                
                # Prompt for exam if recognized
                if recognized_this_frame and recognized_person_name is None and best_match_name_for_prompt is not None:
                    recognized_person_name = best_match_name_for_prompt
                    CURRENT_EXAM_PERSON_ENCODING = best_match_encoding_for_prompt
                    CURRENT_EXAM_PERSON_NAME = recognized_person_name

                    face_detection_active = False # Pause initial verification detection
                    ask_proceed_for_exam(recognized_person_name) 
                    
                # Display initial verification rectangles and names
                for (top, right, bottom, left), name in zip(face_locations, current_frame_face_names):
                    top *= 4
                    right *= 4
                    bottom *= 4
                    left *= 4
                    cv2.rectangle(frame, (left, top), (right, bottom), (0, 255, 0) if name != "Unknown" else (0, 0, 255), 2)
                    cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 255, 0) if name != "Unknown" else (0, 0, 255), cv2.FILLED)
                    font = cv2.FONT_HERSHEY_DUPLEX
                    cv2.putText(frame, name, (left + 6, bottom - 6), font, 0.8, (255, 255, 255), 1)
                
                # Update status label for initial verification
                if len(face_locations) > 0:
                    if "Unknown" in current_frame_face_names:
                        status_label.config(text="Face(s) detected. Unknown person(s) present. 🚫")
                        feed_text = "Unknown Face"
                        feed_text_color = (0, 0, 255) # Red
                    else:
                        recognized_names_display = ', '.join(name for name in current_frame_face_names if name != 'Unknown')
                        if recognized_names_display:
                            status_label.config(text=f"Recognized: {recognized_names_display}. ✅")
                            feed_text = f"Recognized: {recognized_names_display}"
                            feed_text_color = (0, 255, 0) # Green
                        else:
                            status_label.config(text="Face(s) detected. Unknown person(s) present. 🚫")
                            feed_text = "Unknown Face"
                            feed_text_color = (0, 0, 255) # Red
                else:
                    status_label.config(text="No face detected. Looking for faces to verify...")
                    feed_text = "No Face Detected"
                    feed_text_color = (255, 255, 255) # White
            else:
                # This state implies camera is open but neither initial verification nor exam is active
                if recognized_person_name:
                    status_label.config(text=f"Recognized {recognized_person_name}. Waiting for exam decision...")
                    feed_text = f"Waiting for {recognized_person_name}..."
                    feed_text_color = (255, 165, 0) # Orange
                else:
                    status_label.config(text="Camera idle. Awaiting action.")
                    feed_text = "Camera Idle"
                    feed_text_color = (200, 200, 200) # Light Gray


            # Add text to the frame regardless of mode
            cv2.putText(frame, feed_text, (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, feed_text_color, 2, cv2.LINE_AA)

            cv2image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGBA)
            img = Image.fromarray(cv2image)
            imgtk = ImageTk.PhotoImage(image=img)

            photo_label.imgtk = imgtk
            photo_label.config(image=imgtk)

            # Schedule next update only if *either* mode is active
            if face_detection_active or EXAM_ACTIVE:
                photo_label.after(10, update_feed)
        else:
            messagebox.showwarning("Camera Warning", "Could not read frame from camera. It might be disconnected or used by another application.")
            release_camera()
    else:
        open_button.config(state=tk.NORMAL)


def ask_proceed_for_exam(person_name):
    """
    Asks the recognized person if they want to proceed for the exam.
    """
    global face_detection_active, recognized_person_name, last_face_check_time

    status_label.config(text=f"Recognized {person_name}. Proceed for exam?")

    result = messagebox.askyesno(
        "Proceed to Exam?",
        f"Welcome, {person_name}!\n\nDo you want to proceed for the exam?",
        parent=root
    )

    if result:
        show_exam_interface(person_name)
        
    else:
        messagebox.showinfo("Action Cancelled", "Login cancelled. Returning to camera for next verification.")
        status_label.config(text="Login cancelled. Please present your face for verification.")
        recognized_person_name = None
        face_detection_active = True
        status_label.config(text="Camera active. Looking for faces to verify...")
        last_face_check_time = time.time() * 1000 # Reset timer for initial detection to be immediate


def release_camera():
    """
    Releases the camera resource and cleans up.
    """
    global cap, photo_label, face_detection_active, recognized_person_name, EXAM_ACTIVE, no_face_frames_count, last_face_check_time
    if cap:
        cap.release()
        cap = None
    if photo_label:
        # Clear the image
        photo_label.config(image='')
        # Don't pack_forget photo_label itself if it's reused, just its parent frame.
    
    # Hide the main camera frame when camera is off
    if main_camera_frame:
        main_camera_frame.pack_forget()

    cv2.destroyAllWindows()
    status_label.config(text="Camera off. Click 'Open Camera' to start verification.")
    open_button.config(state=tk.NORMAL)
    face_detection_active = False
    EXAM_ACTIVE = False # Ensure exam mode is off
    recognized_person_name = None
    no_face_frames_count = 0 # Reset buffer on camera release
    last_face_check_time = 0 # Reset timer

#----------------------------------------------------------------------------------------------------------------------

# --- Functions for Exam Interface within Main Window ---

def show_exam_interface(person_name):
    """
    Hides verification UI and displays exam UI on the same root window.
    """
    global exam_warning_count, EXAM_ACTIVE, current_question_index, no_face_frames_count, last_face_check_time
    global instructions_frame, button_frame, cbt_frame, exam_status_label, question_label, options_buttons

    # Reset exam state variables
    exam_warning_count = 0
    no_face_frames_count = 0 # Reset buffer when starting exam
    EXAM_ACTIVE = True # Activate exam monitoring loop
    current_question_index = 0
    last_face_check_time = time.time() * 1000 # Initialize timer when exam starts

    # Hide verification UI elements
    instructions_frame.pack_forget()
    button_frame.pack_forget()
    # status_label remains, but its text will be managed by exam status

    # Ensure main_camera_frame is packed and photo_label is visible
    main_camera_frame.pack(pady=10, padx=10, fill="both", expand=True)
    photo_label.pack(side=tk.TOP, pady=5) # Ensure photo_label is packed if its parent was packed_forget()

    # --- CBT Question Section ---
    if cbt_frame is None:
        cbt_frame = tk.Frame(root, bd=2, relief="groove")
        
        tk.Label(cbt_frame, text=f"Hello, {person_name}! Welcome to your exam.", font=('Arial', 12, 'bold')).pack(pady=10)

        question_label = tk.Label(cbt_frame, text="", font=('Arial', 12), wraplength=700, justify=tk.LEFT)
        question_label.pack(pady=10)

        options_frame = tk.Frame(cbt_frame)
        options_frame.pack(pady=5)
        
        for i in range(4):
            btn = tk.Button(options_frame, text=f"Option {i+1}", font=('Arial', 10), width=50, height=2,
                            command=lambda i=i: check_answer(dummy_questions[current_question_index]["options"][i]))
            btn.pack(pady=2)
            options_buttons.append(btn)

        # "End Exam" Button
        tk.Button(cbt_frame, text="End Exam", command=lambda: logout_from_exam("User manually ended exam."),
                width=20, height=2, bg="#dc3545", fg="white", font=('Arial', 10, 'bold')).pack(pady=15)
        
        # This replaces the main status label for exam-specific messages
        exam_status_label = tk.Label(main_camera_frame, text="Monitoring face...", bd=1, relief=tk.SUNKEN, anchor=tk.W, fg="black")
        exam_status_label.pack(side=tk.BOTTOM, fill=tk.X, ipadx=5, ipady=5)
    else:
        # If cbt_frame already exists, update its welcome message and ensure buttons are enabled
        if cbt_frame.winfo_children(): 
            cbt_frame.winfo_children()[0].config(text=f"Hello, {person_name}! Welcome to your exam.")
        for btn in options_buttons:
            btn.config(state=tk.NORMAL) # Ensure buttons are enabled for new questions
        exam_status_label.config(text="Monitoring face...", fg="black") # Reset status label color

    cbt_frame.pack(pady=10, padx=10, fill="both", expand=True)
    
    display_question()
    # The update_feed loop is already running, and will now switch to EXAM_ACTIVE logic

def logout_from_exam(reason=""):
    """
    Logs out the user from the exam, cleans up exam UI, and returns to main verification UI.
    """
    global EXAM_ACTIVE, recognized_person_name, CURRENT_EXAM_PERSON_ENCODING, CURRENT_EXAM_PERSON_NAME
    global instructions_frame, button_frame, cbt_frame, photo_label, exam_status_label, status_label, no_face_frames_count, last_face_check_time

    if EXAM_ACTIVE: # Only process if exam was active
        EXAM_ACTIVE = False # Stop the exam monitoring loop
        
        # Hide exam UI elements
        if cbt_frame:
            cbt_frame.pack_forget()
        if exam_status_label: # Remove exam_status_label
            exam_status_label.pack_forget()
        
        messagebox.showinfo("Exam Ended", f"Exam ended: {reason}\nReturning to verification page.")
        
        # Reset current exam person data
        CURRENT_EXAM_PERSON_ENCODING = None
        CURRENT_EXAM_PERSON_NAME = None

        # Show main verification UI elements
        instructions_frame.pack(pady=5, padx=10, fill=tk.X)
        button_frame.pack(pady=10)
        # Main camera frame remains packed, only its content changes via photo_label
        # The main status_label takes over
        status_label.pack(side=tk.BOTTOM, fill=tk.X, ipadx=5, ipady=5)


        recognized_person_name = None # Reset for new login on main page
        global face_detection_active
        face_detection_active = True # Restart initial verification logic in update_feed
        status_label.config(text="Camera active. Looking for faces to verify...")
        open_button.config(state=tk.NORMAL) # Re-enable open camera button
        no_face_frames_count = 0 # Reset buffer on logout
        last_face_check_time = 0 # Reset timer

def display_question():
    """Displays the current dummy CBT question and its options."""
    global current_question_index, question_label, options_buttons, dummy_questions

    if current_question_index < len(dummy_questions):
        question_data = dummy_questions[current_question_index]
        question_label.config(text=f"Question {current_question_index + 1}: {question_data['question']}")
        
        for i, option_text in enumerate(question_data["options"]):
            options_buttons[i].config(text=option_text, state=tk.NORMAL) # Enable buttons
    else:
        question_label.config(text="End of Exam. Thank you!", fg="blue")
        for btn in options_buttons:
            btn.config(state=tk.DISABLED) # Disable buttons at end of exam
        # Optional: You could auto-logout here, or prompt for final submission


def check_answer(selected_option):
    """Checks the selected answer (dummy functionality) and moves to next question."""
    global current_question_index
    question_data = dummy_questions[current_question_index]
    correct_answer = question_data["answer"]

    if selected_option == correct_answer:
        messagebox.showinfo("Answer", "Correct! 🎉", parent=root) # Parent is root now
    else:
        messagebox.showwarning("Answer", f"Incorrect. The correct answer was: {correct_answer} 😕", parent=root)
    
    # Move to next question automatically after answering
    if current_question_index < len(dummy_questions) - 1:
        current_question_index += 1
        display_question()
    else:
        messagebox.showinfo("Exam Progress", "You have reached the last question. Exam Finished!", parent=root)
        question_label.config(text="Exam Finished!")
        for btn in options_buttons:
            btn.config(state=tk.DISABLED)
        # Optional: auto-logout or final summary

#----------------------------------------------------------------------------------------------------------------------

# --- Tkinter GUI Setup ---

root = tk.Tk()
root.title("Face Verification & Exam Login")
root.geometry("800x700") # Start with a size that accommodates both layouts

root.protocol("WM_DELETE_WINDOW", lambda: [release_camera(), root.destroy()])

# --- UI Frames ---
instructions_frame = tk.Frame(root) # Global reference
button_frame = tk.Frame(root) # Global reference
main_camera_frame = tk.Frame(root, bd=2, relief="groove") # This frame will persist

# --- Instructions Section (initially visible) ---
instructions_text = (
    "**How to Verify Faces & Login:**\n"
    "1. Click 'Open Camera' to start the live feed.\n"
    "2. Ensure you have faces captured using the 'Face Capture App' in the 'captured_faces' directory.\n"
    "3. Position a face in front of the camera until it's recognized.\n"
    "4. If recognized, you'll be prompted to proceed for the exam.\n"
    "5. Select 'Yes' to enter the exam, or 'No' to go back.\n"
    "6. During the exam, your face will be continuously monitored.\n"
    "7. If a different face is detected, you will receive a warning.\n"
    "8. After 3 warnings, you will be automatically logged out.\n"
    "9. Click 'End Exam' to finish the exam and return to verification."
)
instructions_label = tk.Label(instructions_frame, text=instructions_text, justify=tk.LEFT, wraplength=780,
                              font=('Arial', 9), bg='#e0e0e0', fg='#333333', padx=10, pady=10)
instructions_label.pack(pady=5, padx=10, fill=tk.X)
instructions_frame.pack(pady=5, padx=10, fill=tk.X) # Pack initially

separator = tk.Frame(root, height=2, bd=1, relief=tk.SUNKEN)
separator.pack(fill=tk.X, padx=5, pady=5)

# --- Buttons Frame (initially visible) ---
open_button = tk.Button(button_frame, text="Open Camera", command=open_camera,
                        width=15, height=2, bg="#4CAF50", fg="white", font=('Arial', 10, 'bold'))
open_button.pack(side=tk.LEFT, padx=10)

close_button = tk.Button(button_frame, text="Close Camera", command=release_camera,
                         width=15, height=2, bg="#f44336", fg="white", font=('Arial', 10, 'bold'))
close_button.pack(side=tk.LEFT, padx=10)
button_frame.pack(pady=10) # Pack initially

# Photo label will be packed inside main_camera_frame in open_camera
# photo_label is a global variable and will be used by both modes.

# --- Status Label (persists throughout) ---
status_label = tk.Label(root, text="Click 'Open Camera' to begin face verification.", bd=1, relief=tk.SUNKEN, anchor=tk.W)
status_label.pack(side=tk.BOTTOM, fill=tk.X, ipadx=5, ipady=5)

root.mainloop()